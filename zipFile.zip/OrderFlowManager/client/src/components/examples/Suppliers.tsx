import Suppliers from "@/pages/Suppliers";

export default function SuppliersExample() {
  return <Suppliers />;
}
