import Dashboard from "@/pages/Dashboard";

export default function DashboardExample() {
  return <Dashboard />;
}
