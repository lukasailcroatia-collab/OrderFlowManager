import RefillJobs from "@/pages/RefillJobs";

export default function RefillJobsExample() {
  return <RefillJobs />;
}
