import PurchaseOrders from "@/pages/PurchaseOrders";

export default function PurchaseOrdersExample() {
  return <PurchaseOrders />;
}
