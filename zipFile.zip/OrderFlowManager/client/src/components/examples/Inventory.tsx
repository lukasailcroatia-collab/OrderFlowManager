import Inventory from "@/pages/Inventory";

export default function InventoryExample() {
  return <Inventory />;
}
