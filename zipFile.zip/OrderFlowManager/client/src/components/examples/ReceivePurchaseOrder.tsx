import ReceivePurchaseOrder from "@/pages/ReceivePurchaseOrder";

export default function ReceivePurchaseOrderExample() {
  return <ReceivePurchaseOrder />;
}
