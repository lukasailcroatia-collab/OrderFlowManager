import Products from "@/pages/Products";

export default function ProductsExample() {
  return <Products />;
}
