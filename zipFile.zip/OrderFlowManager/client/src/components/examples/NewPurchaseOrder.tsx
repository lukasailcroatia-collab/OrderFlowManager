import NewPurchaseOrder from "@/pages/NewPurchaseOrder";

export default function NewPurchaseOrderExample() {
  return <NewPurchaseOrder />;
}
